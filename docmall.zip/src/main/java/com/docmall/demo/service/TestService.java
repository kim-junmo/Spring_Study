package com.docmall.demo.service;

public interface TestService {
	public String getTime();
}
