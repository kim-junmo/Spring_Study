package com.docmall.demo.mapper;

public interface TimeMapper {
	
	public String getTime();
}
